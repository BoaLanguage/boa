# Blog Post

## Vision
Our vision is that we can produce a variant of Python where programs can have more assurances
about abstractions, achieved through the type system and immutability. Ideally, programmers
will be able to take advantage of the expressiveness and simplicity of Python while also being
able to write elegant and clear code where correctness can be more easily reasoned about. 

## Status

Currently, we have our parsing completely implemented. However we don't have evaluation 
or type checking implemetned yet.


## Next Steps

Our next steps include getting our evaluation to work on all control 
structures and statements.
